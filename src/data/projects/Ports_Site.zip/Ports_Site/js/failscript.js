// Sélectionne le lien et le bouton
const themeLink = document.getElementById('theme_base');
const buttonTheme = document.getElementById('button_theme');

// Initialise l'état actuel (par défaut, princesse1.css)
let currentTheme = 'css/princesse1.css'; // Chemin relatif depuis HTML

// Ajoute un écouteur d'événements pour le clic sur le bouton
buttonTheme.addEventListener('click'), () => {
    if (currentTheme === 'css/princesse1.css') {
        themeLink.href = '../css/princesse2.css'; // Chemin relatif depuis le JS
        currentTheme = '../css/princesse2.css';
    } else {
        themeLink.href = '../css/princesse1.css'; // Retour au premier style
        currentTheme = '../css/princesse1.css';
    }
};
