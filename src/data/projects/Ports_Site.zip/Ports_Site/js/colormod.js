// Récupérer les éléments nécessaires
const themeLink = document.getElementById('theme_base');
const themeButton = document.getElementById('button_theme'); // Correctement lié à l'ID de l'input

// Charger le thème actuel depuis localStorage ou définir le thème par défaut
let currentTheme = localStorage.getItem('theme_base') || 'princesse1';
updateTheme(currentTheme);

// Appliquer le bon état au bouton au chargement
themeButton.checked = currentTheme === 'princesse2';

// Ajouter un événement pour détecter le changement d'état du bouton
themeButton.addEventListener('change', () => {
    if (themeButton.checked) {
        currentTheme = 'princesse2';
    } else {
        currentTheme = 'princesse1';
    }
    updateTheme(currentTheme);

    // Sauvegarder le thème dans localStorage
    localStorage.setItem('theme_base', currentTheme);
});

// Fonction pour mettre à jour le thème
function updateTheme(theme_base) {
    themeLink.href = `css/${theme_base}.css`;
}
