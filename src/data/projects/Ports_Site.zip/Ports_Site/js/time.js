function afficherHeure() {
    const date = new Date();
    let heure = date.getHours();
    let minute = date.getMinutes();
    let seconde = date.getSeconds();

    // Ajouter un zéro devant les chiffres inférieurs à 10
    heure = heure < 10 ? "0" + heure : heure;
    minute = minute < 10 ? "0" + minute : minute;
    seconde = seconde < 10 ? "0" + seconde : seconde;

    const heureActuelle = `${heure}:${minute}:${seconde}`;
    document.getElementById("clock").textContent = heureActuelle;

    setTimeout(afficherHeure, 1000); // Répéter toutes les 1 secondes
}

// Lancer l'horloge après le chargement du DOM
afficherHeure();